<?php

echo "Hello world !";

?>
